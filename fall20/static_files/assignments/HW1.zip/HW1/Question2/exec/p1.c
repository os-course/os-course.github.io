#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>



int 
main(int argc, char** argv) {
    
    int counter = 0;
    
    for(int i=0; i<1000; i++ )
        for(int j=0;i<1000; j++)
            for(int k=0; k<10; k++)
                counter++;

    
    return 0;
}