#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>



int 
main(int argc, char** argv){

    pid_t child_pid = 0;
    child_pid = fork();

    if (child_pid == 0) {
        /* code */
    }
    else if(child_pid < 0) {
        perror("P2.c: error on fork");
        exit(0);
    }
    else
    {
        /* code */
    }
    
    return 0;
}