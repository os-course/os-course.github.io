import numpy as np
from ple import PLE
from ple.games.waterworld import WaterWorld

# Making an agent from game env
agent = WaterWorld(width=256, height=256, num_creeps=8)

# Creating a game environment (use lower fps so we can see whats happening a little easier)
env = PLE(agent, fps=15, force_fps=False, display_screen=True)

env.init()
actions = env.getActionSet()
for i in range(1000):
    if env.game_over():
        env.reset_game()

    action = actions[np.random.randint(0, len(actions))]  # random actions
    env.act(action)
